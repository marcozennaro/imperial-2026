#include <Arduino.h>

constexpr unsigned long MODEM_BAUD    = 19200;
constexpr unsigned long REPLY_IDLE_MS = 100;   // stop once the modem has been silent this long
constexpr unsigned long REPLY_MAX_MS  = 2000;  // hard cap per command

// Forward modem output to the Serial Monitor byte by byte.
// Waits for the first byte (up to maxMs), then returns as soon as the line goes quiet.
void drainModem(unsigned long maxMs = REPLY_MAX_MS) {
  const unsigned long start = millis();
  unsigned long last = start;
  bool gotData = false;

  while (millis() - start < maxMs) {
    if (Serial1.available()) {
      Serial.write(Serial1.read());
      last = millis();
      gotData = true;
    } else if (gotData && millis() - last >= REPLY_IDLE_MS) {
      break;
    }
  }
}

void sendCommand(const char *cmd) {
  Serial.print("> ");
  Serial.println(cmd);
  Serial1.println(cmd);
  drainModem();
}

void setup() {
  Serial.begin(9600);
  while (!Serial && millis() < 3000);   // wait for Serial Monitor (native-USB boards)

  Serial1.begin(MODEM_BAUD);
  drainModem(1000);                     // flush any boot banner

  sendCommand("AT+ID");                 // prints DevAddr, DevEui, AppEui
}

void loop() {
  // nothing to do
}

