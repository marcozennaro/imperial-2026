@ECHO OFF
SETLOCAL ENABLEDELAYEDEXPANSION
setlocal
REM go to the folder where this bat script is located
cd /d %~dp0

set /a EXPECTED_CLI_MAJOR=0
set /a EXPECTED_CLI_MINOR=18

FOR %%I IN (.) DO SET DIRECTORY_NAME=%%~nI%%~xI

where /q arduino-cli
IF ERRORLEVEL 1 (
    GOTO NOTINPATHERROR
)

REM parse arduino-cli version
FOR /F "tokens=1-3 delims==." %%I IN ('arduino-cli version') DO (
    FOR /F "tokens=1-3 delims== " %%X IN ('echo %%I') DO (
        set /A CLI_MAJOR=%%Z
    )
    SET /A CLI_MINOR=%%J
    FOR /F "tokens=1-3 delims== " %%X IN ('echo %%K') DO (
        set /A CLI_REV=%%X
    )
)

if !CLI_MAJOR! LEQ !EXPECTED_CLI_MAJOR! if !CLI_MINOR! LSS !EXPECTED_CLI_MINOR! GOTO UPGRADECLI

if !CLI_MAJOR! NEQ !EXPECTED_CLI_MAJOR! (
    echo You're using an untested version of Arduino CLI, this might cause issues (found: %CLI_MAJOR%.%CLI_MINOR%.%CLI_REV%, expected: %EXPECTED_CLI_MAJOR%.%EXPECTED_CLI_MINOR%.x )
) else (
    if !CLI_MINOR! NEQ !EXPECTED_CLI_MINOR! (
        echo You're using an untested version of Arduino CLI, this might cause issues (found: %CLI_MAJOR%.%CLI_MINOR%.%CLI_REV%, expected: %EXPECTED_CLI_MAJOR%.%EXPECTED_CLI_MINOR%.x )
    )
)

echo Finding Arduino Mbed core...

(arduino-cli core list  2> nul) | findstr "arduino:mbed_nicla"
IF %ERRORLEVEL% NEQ 0 (
    GOTO INSTALLMBEDCORE
)

:AFTERINSTALLMBEDCORE

echo Finding Arduino Mbed core OK

echo Finding Arduino Nicla Vision...

set COM_PORT=""

for /f "tokens=1" %%i in ('arduino-cli board list ^| findstr "Arduino Nicla Vision"') do (
    set COM_PORT=%%i
)

IF %COM_PORT% == "" (
    GOTO NOTCONNECTED
)

echo Finding Arduino Nicla Vision OK at %COM_PORT%

CALL arduino-cli upload -p %COM_PORT% --fqbn arduino:mbed_nicla:nicla_vision  --input-dir .

IF %ERRORLEVEL% NEQ 0 (
    GOTO FLASHINGFAILEDERROR
)

echo Flashed your Arduino Nicla Vision development board
echo To set up your development with Edge Impulse, run 'edge-impulse-daemon'
echo To run your impulse on your development board, run 'edge-impulse-run-impulse'

@pause
exit /b 0

:NOTINPATHERROR
echo Cannot find 'arduino-cli' in your PATH. Install the Arduino CLI before you continue
echo Installation instructions: https://arduino.github.io/arduino-cli/latest/
@pause
exit /b 1

:INSTALLMBEDCORE
echo Installing Arduino Mbed core...
arduino-cli core update-index
arduino-cli core install arduino:mbed_nicla@3.2.0
echo Installing Arduino Mbed core OK
GOTO AFTERINSTALLMBEDCORE

:NOTCONNECTED
echo Cannot find a connected Arduino Nicla Vision development board via 'arduino-cli board list'
echo If your board is connected, double-tap on the RESET button to bring the board in recovery mode
@pause
exit /b 1

:UPGRADECLI
echo You need to upgrade your Arduino CLI version (now: %CLI_MAJOR%.%CLI_MINOR%.%CLI_REV%, but required: %EXPECTED_CLI_MAJOR%.%EXPECTED_CLI_MINOR%.x or higher)
echo See https://arduino.github.io/arduino-cli/installation/ for upgrade instructions
@pause
exit /b 1

:FLASHINGFAILEDERROR
echo Flashing failed. Here are some options:
echo If your error is 'incorrect FQBN' you'll need to upgrade the Arduino core via:
echo      $ arduino-cli core update-index
echo      $ arduino-cli core install arduino:mbed_nicla@3.2.0
echo Otherwise, double tap the RESET button to load the bootloader and try again
@pause
exit /b %ERRORLEVEL%
