#include <Arduino.h>
#include <Wire.h>

static bool is_join = false;
int timeout_ms = 12000;		// Join timeout: 12000 ms
char msg[64];
unsigned long lastSendTime = 0;  // Timer to send a new value every minute
unsigned long counter = 0;  // Counter of sent messages

// Function to send a command to Serial1 and print the response
void sendCommand(String command) {
    Serial.print("Send cmd: ");
    Serial.println(command);
    Serial1.println(command);
    delay(1000);  			// wait for answer
    while (Serial1.available()) {
        Serial.print(Serial1.readString());
    }
}

void sendLoRaMessage() {
	char hexString[9];   // 8 characters + terminator '\0'

	snprintf(hexString, sizeof(hexString), "%08lX", (unsigned long)counter);
    counter++;

    Serial.print("Send LoraWan msg: ");
    Serial.println(hexString);

    // Send msg using AT command
    sendCommand("AT+MSG=\"" + String(hexString) + "\"");
}


void setup() {
	unsigned long startMillis;
	int index = 0;
	int ch;

	memset(msg, 0, sizeof(msg));

    // Initialize Serial Monitor
    Serial.begin(9600);
    delay(1000); // Allow time for Serial Monitor to initialize

    // Initialize Serial1 for communication with LoRaWAN modem
    Serial1.begin(19200); 
    delay(1000);
    // Check if Serial1 has data and print it
    while (Serial1.available()) {
        Serial.print(Serial1.readString());
    }

    // ===================================================
    // Starting LoRaWAN Modem Configuration
    // ===================================================
    Serial.println("Starting LoRaWAN Modem Configuration.");

	// Retrieve modem version and ID
	sendCommand("AT+VER");
	sendCommand("AT+ID");

	// Set up LoRaWAN parameters
	sendCommand("AT+MODE=LWOTAA"); 		// Set mode to LWOTAA
	sendCommand("AT+DR=EU868");   		// Set data rate for EU868
	sendCommand("AT+CH=NUM,0-7"); 		// Set channels to 0-7

	// Configure APPKEY
	// device configuration (replace the values below with your own from TTN):
	// JoinEUI (the AppEUI obtained before): YOUR_JOIN_EUI
	// DevEUI (obtained before): YOUR_DEV_EUI
	// AppKey (generated in TTN application): YOUR_APP_KEY
	// 
    sendCommand("AT+ID=APPEUI,\"0000000000000001\"");
	sendCommand("AT+KEY=APPKEY,\"YOUR_APP_KEY\"");   // <-- paste the 32-hex-digit AppKey from your TTN device
    sendCommand("AT+ID");

	// Set data rate to DR7
	sendCommand("Tx: AT+DR=DR7");

	// Joining
	startMillis = millis();
	sendCommand("Tx: AT+JOIN");
    do
    {
        while (Serial1.available() > 0) {
            ch = Serial1.read();
			if (index < sizeof(msg) - 1) {
				msg[index++] = ch;
				msg[index] = '\0';
			}
            Serial.print((char)ch);
            delay(2);
        }

        if (strstr(msg, "+JOIN: Network joined") != NULL) {
			is_join = true;
            break;
        }

    } while (millis() - startMillis < timeout_ms);
}

void loop() {
    if (!is_join) {
        return;
    }

    if (millis() - lastSendTime > 30000) { // every 30 sec
        lastSendTime = millis();
        sendLoRaMessage();
    }
}


